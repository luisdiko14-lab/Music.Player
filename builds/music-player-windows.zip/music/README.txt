Place your audio and video files in this folder. The player scans it when it starts.
